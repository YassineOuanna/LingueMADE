# LingoPro — Pro Starter (Web + Mobile + API)

Production-minded starter with:
- Turborepo workspaces
- API: Express + Prisma (Postgres) + JWT (access/refresh) + rate limiting, CORS, Helmet
- Spaced repetition: **FSRS** (modern) + SM-2 fallback
- Realtime: Socket.IO (live streaks, XP toasts)
- Queue & cache: BullMQ + Redis (optional) for async scoring, email, webhooks
- OpenAPI with Swagger UI (`/docs`)
- Stripe subscriptions + Billing Portal stub
- Admin app with CRUD tables (paginated), role-based UI
- Web app using Next.js App Router + Tailwind + TanStack Query + Zustand + Framer Motion
- Mobile app (Expo) with SecureStore + React Query
- Analytics hooks (PostHog/Sentry stubs)
- CI: GitHub Actions (lint, typecheck, build)
- Code quality: ESLint, Prettier, Husky (pre-commit), lint-staged
- Docker Compose: Postgres, Redis, API

> Designed to deploy on Vercel (web/admin) + Railway (API/Redis) + Supabase/Neon (Postgres).
