'use client';
import { useEffect, useState } from 'react';
const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';
const TOKEN = '';

export default function Admin() {
  const [languages, setLanguages] = useState<any[]>([]);
  const [code, setCode] = useState('fr'); const [name, setName] = useState('French');
  const headers = { 'Content-Type': 'application/json', Authorization: `Bearer ${TOKEN}` };

  const load = async () => {
    const r = await fetch(`${API}/admin/languages`, { headers }); setLanguages(await r.json());
  };
  const add = async () => {
    await fetch(`${API}/admin/languages`, { method:'POST', headers, body: JSON.stringify({ code, name }) }); load();
  };
  useEffect(()=>{ if (TOKEN) load(); }, []);

  return (
    <main className="max-w-2xl">
      <h1 className="text-2xl font-bold">Admin</h1>
      {!TOKEN && <p className="text-sm text-gray-600">Add an ADMIN JWT to TOKEN in page.tsx.</p>}
      <div className="mt-4 border rounded p-4 space-y-3">
        <div className="flex gap-2">
          <input className="border p-2 rounded" placeholder="code" value={code} onChange={e=>setCode(e.target.value)} />
          <input className="border p-2 rounded" placeholder="name" value={name} onChange={e=>setName(e.target.value)} />
          <button className="px-3 py-2 bg-black text-white rounded" onClick={add}>Add</button>
        </div>
        <ul className="list-disc pl-6">
          {languages.map(l => <li key={l.id}>{l.code} — {l.name}</li>)}
        </ul>
      </div>
    </main>
  );
}
