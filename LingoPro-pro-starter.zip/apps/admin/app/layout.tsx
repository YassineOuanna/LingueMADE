import './globals.css';
export const metadata = { title: 'LingoPro Admin' };
export default function Layout({ children }: { children: React.ReactNode }) {
  return (<html><body className="p-6">{children}</body></html>);
}
