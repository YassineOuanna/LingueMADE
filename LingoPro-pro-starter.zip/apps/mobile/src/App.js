import React, { useState } from 'react';
import { SafeAreaView, Text, TextInput, Button, FlatList, View } from 'react-native';
import * as SecureStore from 'expo-secure-store';

const API = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:4000';

export default function App() {
  const [email, setEmail] = useState('pro@example.com');
  const [password, setPassword] = useState('Password#123');
  const [access, setAccess] = useState(null);
  const [courses, setCourses] = useState([]);

  const register = async () => {
    const r = await fetch(`${API}/auth/register`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({email,password}) });
    const data = await r.json();
    if (data.access) { setAccess(data.access); await SecureStore.setItemAsync('access', data.access); }
  };

  const load = async () => {
    const r = await fetch(`${API}/courses`, { headers: { Authorization: `Bearer ${access}` } });
    setCourses(await r.json());
  };

  return (
    <SafeAreaView style={{ flex:1, padding:16 }}>
      <Text style={{ fontSize:24, fontWeight:'bold' }}>LingoPro Pro (Mobile)</Text>
      {!access ? (
        <View>
          <TextInput style={{ borderWidth:1, padding:8, marginVertical:8 }} placeholder="Email" value={email} onChangeText={setEmail} />
          <TextInput style={{ borderWidth:1, padding:8, marginVertical:8 }} placeholder="Password" secureTextEntry value={password} onChangeText={setPassword} />
          <Button title="Create account" onPress={register} />
        </View>
      ) : (
        <View>
          <Button title="Load Courses" onPress={load} />
          <FlatList data={courses} keyExtractor={i=>i.id} renderItem={({item}) => (
            <View style={{ padding:12, borderWidth:1, marginVertical:6 }}>
              <Text style={{ fontWeight:'600' }}>{item.title}</Text>
              <Text>{item.locked ? 'Premium' : 'Free'}</Text>
            </View>
          )} />
        </View>
      )}
    </SafeAreaView>
  );
}
