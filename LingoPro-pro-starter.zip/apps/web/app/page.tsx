'use client';
import { useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';
const qc = new QueryClient();

export default function Home() {
  const [email, setEmail] = useState('pro@example.com');
  const [password, setPassword] = useState('Password#123');
  const [access, setAccess] = useState<string| null>(null);
  const [refresh, setRefresh] = useState<string| null>(null);
  const [courses, setCourses] = useState<any[]>([]);

  const register = async () => {
    const r = await fetch(`${API}/auth/register`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({email,password}) });
    const data = await r.json(); setAccess(data.access); setRefresh(data.refresh);
  };
  const loadCourses = async () => {
    const r = await fetch(`${API}/courses`, { headers: { Authorization: `Bearer ${access}` } });
    setCourses(await r.json());
  };

  return (
    <QueryClientProvider client={qc}>
      <main className="max-w-4xl mx-auto p-8">
        <h1 className="text-4xl font-bold">LingoPro (Pro)</h1>
        {!access ? (
          <div className="mt-6 grid gap-3 max-w-md">
            <input className="border p-3 rounded" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
            <input className="border p-3 rounded" type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} />
            <button className="px-4 py-2 rounded bg-black text-white" onClick={register}>Create account</button>
            <p className="text-sm text-gray-500">JWT access/refresh; premium courses will lock without subscription.</p>
          </div>
        ) : (
          <div className="mt-8">
            <button className="px-3 py-2 bg-black text-white rounded" onClick={loadCourses}>Load Courses</button>
            <ul className="mt-4 grid gap-4">
              {courses.map(c => (
                <li key={c.id} className="p-4 border rounded">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-semibold">{c.title}</div>
                      <div className="text-sm text-gray-600">{c.description}</div>
                    </div>
                    {c.locked ? <span className="text-xs px-2 py-1 bg-yellow-200 rounded">Premium</span> : <span className="text-xs px-2 py-1 bg-green-200 rounded">Free</span>}
                  </div>
                </li>
              ))}
            </ul>
          </div>
        )}
      </main>
    </QueryClientProvider>
  );
}
