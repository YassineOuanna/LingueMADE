import './globals.css';
export const metadata = { title: 'LingoPro', description: 'Learn languages the pro way' };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en"><body className="bg-gray-50 text-gray-900">{children}</body></html>);
}
