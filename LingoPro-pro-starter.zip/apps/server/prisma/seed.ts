import { PrismaClient } from '@prisma/client'; const prisma = new PrismaClient();
async function main() {
  const es = await prisma.language.upsert({ where: { code: 'es' }, update: {}, create: { code: 'es', name: 'Spanish' } });
  const course = await prisma.course.create({ data: { languageId: es.id, title: 'Spanish Pro Basics', description: 'Greetings + phrases', premium: false } });
  const skill = await prisma.skill.create({ data: { courseId: course.id, title: 'Greetings', order: 1 } });
  const lesson = await prisma.lesson.create({ data: { skillId: skill.id, title: 'Hola y Adiós', order: 1 } });
  await prisma.exercise.createMany({ data: [
    { lessonId: lesson.id, type: 'TRANSLATE', prompt: 'Translate: Hello', options: [], answer: 'Hola' },
    { lessonId: lesson.id, type: 'MCQ', prompt: 'Select "Goodbye"', options: ['Gracias','Adiós','Hola'], answer: 'Adiós' }
  ]});
  console.log('Seeded pro demo');
}
main().finally(()=>prisma.$disconnect());
