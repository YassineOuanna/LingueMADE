import YAML from 'yaml';

export function loadOpenAPIDoc() {
  const doc = {
    openapi: '3.0.0',
    info: { title: 'LingoPro API', version: '0.2.0' },
    paths: {
      '/auth/register': { post: { summary: 'Register', responses: { '200': { description: 'OK' } } } },
      '/auth/login': { post: { summary: 'Login', responses: { '200': { description: 'OK' } } } },
      '/courses': { get: { summary: 'Get courses', responses: { '200': { description: 'OK' } } } },
      '/progress/answer': { post: { summary: 'Submit answer', responses: { '200': { description: 'OK' } } } }
    }
  };
  return doc as any;
}
