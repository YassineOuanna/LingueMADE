import jwt from 'jsonwebtoken';
const secret = process.env.JWT_SECRET!;

export function signAccess(payload: object, expiresIn = '15m') {
  return jwt.sign(payload, secret, { expiresIn });
}
export function signRefresh(payload: object, expiresIn = `${process.env.REFRESH_TOKEN_TTL_DAYS || 30}d`) {
  return jwt.sign(payload, secret, { expiresIn });
}
export function verifyJwt<T = any>(token: string): T {
  return jwt.verify(token, secret) as T;
}
