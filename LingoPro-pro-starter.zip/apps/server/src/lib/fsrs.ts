// Minimal FSRS implementation for scheduling (simplified).
// Ref: https://github.com/open-spaced-repetition
export type ReviewState = { interval: number; ease: number; streak: number; dueAt: Date };
export function fsrs(prev: ReviewState, grade: 1|2|3|4): ReviewState {
  // 1=Again, 2=Hard, 3=Good, 4=Easy
  let { interval, ease, streak } = prev;
  const factors = { 1: -0.2, 2: -0.08, 3: 0, 4: 0.15 } as const;
  if (grade >= 3) {
    streak += 1;
    interval = Math.max(1, Math.round((interval || 1) * (ease + 0.15)));
    ease = Math.max(1.3, ease + factors[grade]);
  } else {
    streak = 0;
    interval = 1;
    ease = Math.max(1.3, ease + factors[grade]);
  }
  const dueAt = new Date(Date.now() + interval * 24 * 60 * 60 * 1000);
  return { interval, ease, streak, dueAt };
}
