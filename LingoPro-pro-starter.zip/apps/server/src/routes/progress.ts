import { Router } from 'express';
import { prisma } from '../index.js';
import { requireAuth } from '../middleware/auth.js';
import { fsrs } from '../lib/fsrs.js';
import { io } from '../index.js';

const router = Router();
router.use(requireAuth);

router.post('/answer', async (req, res) => {
  const user = (req as any).user as { id: string };
  const { exerciseId, correct } = req.body as { exerciseId: string, correct: boolean };
  const existing = await prisma.progress.findFirst({ where: { userId: user.id, exerciseId } });
  const base = existing ?
    { interval: existing.interval, ease: existing.ease, streak: existing.streak, dueAt: existing.dueAt } :
    { interval: 1, ease: 2.5, streak: 0, dueAt: new Date() };

  const next = fsrs({ ...base }, correct ? 4 : 1);
  const xpGain = correct ? 15 : 0;

  const rec = await prisma.progress.upsert({
    where: { id: existing?.id || '' },
    update: { ...next, lastResult: correct ? 'correct' : 'incorrect', xp: (existing?.xp || 0) + xpGain },
    create: { userId: user.id, exerciseId, ...next, lastResult: correct ? 'correct' : 'incorrect', xp: xpGain }
  });

  io.emit(`user:${user.id}:xp`, { delta: xpGain, total: rec.xp });
  res.json({ ok: true, progress: rec });
});

router.get('/me', async (req, res) => {
  const user = (req as any).user as { id: string };
  const stats = await prisma.progress.groupBy({ by: ['userId'], where: { userId: user.id }, _sum: { xp: true } });
  const xp = stats[0]?._sum.xp || 0;
  const streak = await prisma.progress.aggregate({ where: { userId: user.id }, _max: { streak: true } });
  res.json({ xp, bestStreak: streak._max.streak || 0 });
});

export default router;
