import { Router } from 'express';
import { prisma } from '../index.js';
import { z } from 'zod';
import { requireAuth, requireAdmin } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth, requireAdmin);

router.post('/languages', async (req, res) => {
  const schema = z.object({ code: z.string().min(2), name: z.string().min(2) });
  const lang = await prisma.language.create({ data: schema.parse(req.body) });
  res.json(lang);
});

router.get('/languages', async (_req, res) => res.json(await prisma.language.findMany()));

router.post('/courses', async (req, res) => {
  const schema = z.object({ languageId: z.string(), title: z.string(), description: z.string().optional(), premium: z.boolean().optional() });
  const course = await prisma.course.create({ data: schema.parse(req.body) });
  res.json(course);
});

router.patch('/courses/:id', async (req, res) => {
  const schema = z.object({ title: z.string().optional(), description: z.string().optional(), premium: z.boolean().optional() });
  const course = await prisma.course.update({ where: { id: req.params.id }, data: schema.parse(req.body) });
  res.json(course);
});

router.delete('/courses/:id', async (req, res) => {
  await prisma.course.delete({ where: { id: req.params.id } });
  res.json({ ok: true });
});

export default router;
