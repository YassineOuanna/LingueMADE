import { Router } from 'express';
import Stripe from 'stripe';
import express from 'express';
import { prisma } from '../index.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string);

router.post('/checkout', requireAuth, async (req, res) => {
  const user = (req as any).user as { id: string, email?: string };
  const session = await stripe.checkout.sessions.create({
    mode: 'subscription',
    customer_email: (user as any).email,
    line_items: [{ price: req.body.priceId, quantity: 1 }],
    success_url: `${process.env.CLIENT_URL?.split(',')[0]}/success`,
    cancel_url: `${process.env.CLIENT_URL?.split(',')[0]}/billing`
  });
  res.json({ url: session.url });
});

const webhook = express.raw({ type: 'application/json' });
router.post('/webhook', webhook, async (req, res) => {
  const sig = req.headers['stripe-signature'] as string;
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET as string);
  } catch (err: any) {
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }
  switch (event.type) {
    case 'customer.subscription.created':
    case 'customer.subscription.updated': {
      const sub = event.data.object as Stripe.Subscription;
      const email = (sub as any).customer_email || (sub as any).customer_details?.email;
      if (email) {
        const user = await prisma.user.findUnique({ where: { email } });
        if (user) {
          await prisma.subscription.upsert({
            where: { stripeId: sub.id },
            update: { status: sub.status, currentPeriodEnd: new Date(sub.current_period_end * 1000) },
            create: { userId: user.id, stripeId: sub.id, status: sub.status, currentPeriodEnd: new Date(sub.current_period_end * 1000) }
          });
        }
      }
      break;
    }
    case 'customer.subscription.deleted': {
      const sub = event.data.object as Stripe.Subscription;
      await prisma.subscription.update({ where: { stripeId: sub.id }, data: { status: 'canceled' } }).catch(()=>{});
      break;
    }
  }
  res.json({ received: true });
});

export default router;
