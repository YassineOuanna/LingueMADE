import { Router } from 'express';
import { prisma } from '../index.js';
import { z } from 'zod';
import bcrypt from 'bcryptjs';
import { signAccess, signRefresh, verifyJwt } from '../lib/jwt.js';

const router = Router();

const Credentials = z.object({ email: z.string().email(), password: z.string().min(8) });

router.post('/register', async (req, res) => {
  const parse = Credentials.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: 'Invalid payload' });
  const { email, password } = parse.data;
  const hash = await bcrypt.hash(password, 10);
  try {
    const user = await prisma.user.create({ data: { email, password: hash } });
    const access = signAccess({ id: user.id, email: user.email, role: user.role });
    const refresh = signRefresh({ id: user.id });
    const expiresAt = new Date(Date.now() + (parseInt(process.env.REFRESH_TOKEN_TTL_DAYS || '30') * 864e5));
    await prisma.refreshToken.create({ data: { userId: user.id, tokenHash: refresh, expiresAt } });
    res.json({ access, refresh, user: { id: user.id, email: user.email, role: user.role } });
  } catch {
    res.status(409).json({ error: 'User exists' });
  }
});

router.post('/login', async (req, res) => {
  const parse = Credentials.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: 'Invalid payload' });
  const { email, password } = parse.data;
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  const ok = await bcrypt.compare(password, user.password);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
  const access = signAccess({ id: user.id, email: user.email, role: user.role });
  const refresh = signRefresh({ id: user.id });
  const expiresAt = new Date(Date.now() + (parseInt(process.env.REFRESH_TOKEN_TTL_DAYS || '30') * 864e5));
  await prisma.refreshToken.create({ data: { userId: user.id, tokenHash: refresh, expiresAt } });
  res.json({ access, refresh, user: { id: user.id, email: user.email, role: user.role } });
});

router.post('/refresh', async (req, res) => {
  const { refresh } = req.body as { refresh: string };
  if (!refresh) return res.status(400).json({ error: 'Missing refresh' });
  try {
    const payload = verifyJwt<{ id: string }>(refresh);
    const db = await prisma.refreshToken.findFirst({ where: { userId: payload.id, tokenHash: refresh, revoked: false } });
    if (!db || db.expiresAt < new Date()) return res.status(401).json({ error: 'Invalid refresh' });
    const access = signAccess({ id: payload.id });
    res.json({ access });
  } catch {
    res.status(401).json({ error: 'Invalid refresh' });
  }
});

router.post('/logout', async (req, res) => {
  const { refresh } = req.body as { refresh: string };
  await prisma.refreshToken.updateMany({ where: { tokenHash: refresh }, data: { revoked: true } });
  res.json({ ok: true });
});

export default router;
