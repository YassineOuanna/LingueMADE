import { Router } from 'express';
import { prisma } from '../index.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  const user = (req as any).user as { id: string };
  const subs = await prisma.subscription.findFirst({ where: { userId: user.id, status: { in: ['active','trialing'] } } });
  const courses = await prisma.course.findMany({ include: { language: true } });
  const visible = courses.map(c => ({ ...c, locked: c.premium && !subs }));
  res.json(visible);
});

export default router;
