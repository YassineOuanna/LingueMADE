import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import http from 'http';
import { Server as SocketServer } from 'socket.io';
import { PrismaClient } from '@prisma/client';
import jwt from 'jsonwebtoken';
import swaggerUi from 'swagger-ui-express';
import { loadOpenAPIDoc } from './lib/openapi.js';

import authRouter from './routes/auth.js';
import adminRouter from './routes/admin.js';
import courseRouter from './routes/courses.js';
import progressRouter from './routes/progress.js';
import stripeRouter from './routes/stripe.js';

export const prisma = new PrismaClient();

const app = express();
const server = http.createServer(app);
export const io = new SocketServer(server, {
  cors: { origin: (process.env.CLIENT_URL?.split(',') || ['*']), credentials: true }
});

io.on('connection', (socket) => {
  socket.emit('hello', { ok: true });
});

app.use(express.json({ limit: '5mb' }));
app.use(cors({ origin: process.env.CLIENT_URL?.split(',') || true, credentials: true }));
app.use(helmet());

const limiter = rateLimit({ windowMs: 60_000, max: 100 });
app.use(limiter);

app.get('/health', (_req, res) => res.json({ ok: true }));

const openapi = loadOpenAPIDoc();
app.use('/docs', swaggerUi.serve, swaggerUi.setup(openapi));

app.use('/auth', authRouter);
app.use('/admin', adminRouter);
app.use('/courses', courseRouter);
app.use('/progress', progressRouter);
app.use('/stripe', stripeRouter);

const port = process.env.PORT || 4000;
server.listen(port, () => console.log(`API http://localhost:${port}  Docs: /docs`));
